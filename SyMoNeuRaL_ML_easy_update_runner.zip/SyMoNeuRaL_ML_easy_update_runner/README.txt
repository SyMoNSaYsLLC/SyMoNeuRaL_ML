SyMoNeuRaL_ML easy update runner

Put this zip in ~/SyMoNeuRaL_ML, then run:

cd ~/SyMoNeuRaL_ML
rm -rf .symon_update
mkdir -p .symon_update
unzip -q ./SyMoNeuRaL_ML_easy_update_runner.zip -d .symon_update
./.symon_update/SyMoNeuRaL_ML_easy_update_runner/UPDATE.sh

This avoids pasting long heredoc blocks.
