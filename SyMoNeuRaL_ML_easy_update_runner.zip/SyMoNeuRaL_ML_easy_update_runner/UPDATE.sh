#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
if [ ! -f "$ROOT/pyproject.toml" ] || [ ! -d "$ROOT/scripts" ]; then
  echo "ERROR: Run this from the SyMoNeuRaL_ML repository root." >&2
  echo "Example:" >&2
  echo "  cd ~/SyMoNeuRaL_ML" >&2
  echo "  ./.symon_update/SyMoNeuRaL_ML_easy_update_runner/UPDATE.sh" >&2
  exit 1
fi

echo "== SyMoNeuRaL_ML easy update runner =="
echo "repo: $ROOT"

mkdir -p scripts docs updates

# Update .gitignore safely without a giant pasted shell block.
python3 - <<'PY'
from pathlib import Path
p = Path('.gitignore')
s = p.read_text() if p.exists() else ''
entries = [
    '# Python cache/build artifacts',
    '__pycache__/',
    '**/__pycache__/',
    '*.py[cod]',
    '*$py.class',
    '.pytest_cache/',
    '.mypy_cache/',
    '.ruff_cache/',
    '*.egg-info/',
    'symoneural_ml.egg-info/',
]
for e in entries:
    if e not in s:
        if s and not s.endswith('\n'):
            s += '\n'
        s += e + '\n'
p.write_text(s)
PY

cat > scripts/apply_update_zip.sh <<'EOF2'
#!/usr/bin/env bash
set -euo pipefail

ZIP="${1:-}"
if [ ! -f pyproject.toml ] || [ ! -d scripts ]; then
  echo "Run from the SyMoNeuRaL_ML repository root." >&2
  exit 1
fi
if [ -z "$ZIP" ]; then
  echo "Usage: ./scripts/apply_update_zip.sh ./update.zip" >&2
  exit 2
fi
if [ ! -f "$ZIP" ]; then
  echo "Update zip not found: $ZIP" >&2
  exit 2
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "Extracting update: $ZIP"
unzip -q "$ZIP" -d "$TMP"

APPLY="$(find "$TMP" -type f \( -name "UPDATE.sh" -o -name "apply_main_hotfix.sh" -o -name "apply_update.sh" -o -name "apply_repo_update.sh" -o -name "apply_hotfix.sh" -o -name "apply_update_runner_hotfix.sh" \) | sort | head -n 1)"

if [ -z "$APPLY" ]; then
  echo "No known update script found inside $ZIP." >&2
  echo "Expected: UPDATE.sh, apply_main_hotfix.sh, apply_update.sh, apply_repo_update.sh, apply_hotfix.sh, or apply_update_runner_hotfix.sh" >&2
  exit 3
fi

chmod +x "$APPLY"
echo "Running: $APPLY"
"$APPLY"
EOF2

cat > scripts/apply_repo_updates.sh <<'EOF2'
#!/usr/bin/env bash
set -euo pipefail

if [ ! -f pyproject.toml ] || [ ! -d scripts ]; then
  echo "Run from the SyMoNeuRaL_ML repository root." >&2
  exit 1
fi

mapfile -t ZIPS < <(
  {
    find . -maxdepth 1 -type f \( -name "*update*.zip" -o -name "*hotfix*.zip" \) 2>/dev/null || true
    find updates -maxdepth 1 -type f -name "*.zip" 2>/dev/null || true
    find update_zips -maxdepth 1 -type f -name "*.zip" 2>/dev/null || true
  } | sort -u
)

if [ "${#ZIPS[@]}" -eq 0 ]; then
  echo "No update zips found."
  exit 0
fi

for z in "${ZIPS[@]}"; do
  echo
  echo "== Applying $z =="
  ./scripts/apply_update_zip.sh "$z"
done
EOF2

cat > scripts/import_update_zip.sh <<'EOF2'
#!/usr/bin/env bash
set -euo pipefail
SRC="${1:-}"
if [ -z "$SRC" ] || [ ! -f "$SRC" ]; then
  echo "Usage: ./scripts/import_update_zip.sh /path/to/update.zip" >&2
  exit 2
fi
mkdir -p updates
cp "$SRC" "updates/$(basename "$SRC")"
echo "Imported: updates/$(basename "$SRC")"
EOF2

cat > docs/UPDATE_ZIP_WORKFLOW.md <<'EOF2'
# Update Zip Workflow

Put update zips directly in the repository root or in `updates/`.

## Apply one update zip

```bash
./scripts/apply_update_zip.sh ./Some_Update.zip
```

## Apply every update zip

```bash
./scripts/apply_repo_updates.sh
```

Future SyMoNeuRaL update zips should include a top-level `UPDATE.sh` script.
EOF2

chmod +x scripts/apply_update_zip.sh scripts/apply_repo_updates.sh scripts/import_update_zip.sh
find bin scripts -type f -exec chmod +x {} \; 2>/dev/null || true

git rm -r --cached app/__pycache__ 2>/dev/null || true
git rm -r --cached symoneural_ml.egg-info 2>/dev/null || true

git add .gitignore scripts/apply_update_zip.sh scripts/apply_repo_updates.sh scripts/import_update_zip.sh docs/UPDATE_ZIP_WORKFLOW.md bin/ scripts/

if git diff --cached --quiet; then
  echo "No staged changes to commit."
else
  git commit -m "chore: add simple repo-root update runner and ignore python caches"
  git push origin main
fi

echo
echo "Done. Future repo-root update command:"
echo "  ./scripts/apply_update_zip.sh ./UPDATE_ZIP_NAME.zip"
