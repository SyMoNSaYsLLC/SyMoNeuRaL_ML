# SyMoNeuRaL_ML hotfix package

Run from the repository root:

```bash
unzip SyMoNeuRaL_ML_main_hotfix_update.zip -d /tmp/symon_hotfix
cd ~/SyMoNeuRaL_ML
/tmp/symon_hotfix/symoneural_main_hotfix_update/scripts/apply_main_hotfix.sh
```

This updates README.md, patches install.sh and doctor.sh, adds normalize_engine_timestamps.sh, commits, and pushes to origin main.
