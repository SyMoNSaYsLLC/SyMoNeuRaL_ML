#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
if [ ! -f "$ROOT/pyproject.toml" ] || [ ! -d "$ROOT/scripts" ]; then
  echo "Run this from the SyMoNeuRaL_ML repository root." >&2
  exit 1
fi

PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "== Applying SyMoNeuRaL_ML hotfix =="
echo "root: $ROOT"

cp "$PATCH_DIR/../README.md" "$ROOT/README.md"

python3 - <<'PY'
from pathlib import Path

p = Path("scripts/install.sh")
s = p.read_text()
for old, new in {
    'mkdir -p /mnt/data/symoneural_handoff_jobs': 'mkdir -p "$PWD/data/symoneural_handoff_jobs"',
    'mkdir -p /mnt/data/symoneural_coder_jobs': 'mkdir -p "$PWD/data/symoneural_coder_jobs"',
    'mkdir -p /mnt/data/symoneural_handoff_jobs /mnt/data/symoneural_coder_jobs': 'mkdir -p "$PWD/data/symoneural_handoff_jobs" "$PWD/data/symoneural_coder_jobs"',
    'mkdir -p /mnt/data': 'mkdir -p "$PWD/data"',
}.items():
    s = s.replace(old, new)

marker = 'mkdir -p "$PWD/data/symoneural_handoff_jobs" "$PWD/data/symoneural_coder_jobs" "$PWD/logs" "$PWD/models"'
if marker not in s:
    lines = s.splitlines()
    insert_at = 0
    for i, line in enumerate(lines):
        if "python3 -m venv" in line or "pip install" in line:
            insert_at = i
            break
    lines.insert(insert_at, marker)
    s = "\n".join(lines) + "\n"

p.write_text(s)

p = Path("scripts/doctor.sh")
s = p.read_text()
if 'PYTHON_BIN="$PWD/.venv/bin/python"' not in s:
    s = s.replace(
        "set -euo pipefail",
        'set -euo pipefail\nPYTHON_BIN="$PWD/.venv/bin/python"\n[ -x "$PYTHON_BIN" ] || PYTHON_BIN="$(command -v python3)"',
        1,
    )
s = s.replace("python3 - <<", '"$PYTHON_BIN" - <<')
s = s.replace("python3 -c", '"$PYTHON_BIN" -c')
if 'echo "selected python: $PYTHON_BIN"' not in s:
    s = s.replace('echo "root: $ROOT"', 'echo "root: $ROOT"\necho "selected python: $PYTHON_BIN"', 1)
p.write_text(s)
PY

find bin scripts -type f -exec chmod +x {} \;

cat > scripts/normalize_engine_timestamps.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
find engines/llama.cpp engines/stable-diffusion.cpp -exec touch {} +
echo "Engine source timestamps normalized."
EOF
chmod +x scripts/normalize_engine_timestamps.sh

git status --short || true

if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git add README.md scripts/install.sh scripts/doctor.sh scripts/normalize_engine_timestamps.sh bin/ scripts/
  if git diff --cached --quiet; then
    echo "No staged changes to commit."
  else
    git commit -m "fix: improve install doctor and CUDA rebuild docs"
    git push origin main
  fi
else
  echo "Not a git repo; skipping commit/push."
fi

echo "Done."
echo "Next:"
echo "  ./scripts/install.sh"
echo "  ./scripts/doctor.sh"
echo "  ./scripts/normalize_engine_timestamps.sh"
echo "  ./scripts/build_all_cuda.sh"
